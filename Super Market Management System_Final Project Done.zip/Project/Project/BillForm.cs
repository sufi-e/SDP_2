﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class BillForm : Form
    {
        public BillForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"data source=DESKTOP-1CECNH1\SQLEXPRESS;database = market;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            SellerOptionListForm sopt = new SellerOptionListForm();
            sopt.Show();
            this.Hide();
        }
        void populateOrder()
        {
            try
            {
                con.Open();
                string query = "select* from OrderTb";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                OrderDgv.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            log.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            populateOrder();
            populate();
        }
        void filterbycategory()
        {
            try
            {
                con.Open();
                string query = "select* from OrderTb where [P.Method]='" + PaymentCb.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                OrderDgv.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        private void BillForm_Load(object sender, EventArgs e)
        {
            populateOrder();
        }

        private void OrderDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            OrderIdTb.Text = OrderDgv.SelectedRows[0].Cells[0].Value.ToString();
            CustomerIdTb.Text = OrderDgv.SelectedRows[0].Cells[1].Value.ToString();
            SellerIdTb.Text = OrderDgv.SelectedRows[0].Cells[2].Value.ToString();
            ProductIdTb.Text = OrderDgv.SelectedRows[0].Cells[3].Value.ToString();
            QuantityIdTB.Text = OrderDgv.SelectedRows[0].Cells[6].Value.ToString();
            PaymentTb.Text = OrderDgv.SelectedRows[0].Cells[5].Value.ToString();
            PriceTb.Text = OrderDgv.SelectedRows[0].Cells[4].Value.ToString();
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            filterbycategory();
        }
        void populate()
        {
            try
            {
                con.Open();
                string query = "select* from OrderTb";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                OrderDgv.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            log.Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Document Printing\nThanks For Being With Us");
            BillForm bill = new BillForm();
            bill.Show();
            this.Hide();
        }
    }
}
