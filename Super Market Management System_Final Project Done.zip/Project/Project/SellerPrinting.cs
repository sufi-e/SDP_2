﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class SellerPrinting : Form
    {
        public SellerPrinting()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"data source=DESKTOP-1CECNH1\SQLEXPRESS;database = market;Integrated Security=True");
        private void X_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MessageBox.Show("Printing Document\nAnd Opening Seller Menu List\n\nThank You, Sir");
                con.Close();
            }
            catch
            {

            }
            SellerOptionListForm opt = new SellerOptionListForm();
            opt.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
