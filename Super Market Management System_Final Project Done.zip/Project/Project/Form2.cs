﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        int startpoint = 0;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            startpoint += 5;
            myprogress.Value = startpoint;
            if(myprogress.Value== 100)
            {
                myprogress.Value = 0;
                timer2.Stop();
                Form1 log = new Form1();
                this.Hide();
                log.Show();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            
        }

        private void myprogress_progressChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            timer2.Start();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
