﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string SellerName = "";
        SqlConnection con = new SqlConnection(@"data source=DESKTOP-1CECNH1\SQLEXPRESS;database = market;Integrated Security=True");
        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(UnameTb.Text==""|| PassTb.Text=="")
            {
                MessageBox.Show("Enter The User Name and Password");
            }
            else
            {
                if (RoleCb.SelectedIndex > -1)
                {
                    if (RoleCb.SelectedItem.ToString() == "ADMIN")
                    {
                        if (UnameTb.Text == "Admin" && PassTb.Text == "Admin")
                        {
                            OptionListForm optlist = new OptionListForm();
                            optlist.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("If You are the Admin, Enter the correct information");
                        }
                    }
                    else
                    {
                        //MessageBox.Show("You Are in The Seller Section");
                        con.Open();
                        SqlDataAdapter sda = new SqlDataAdapter("Select count (8) from sellerTb1 where SellerName='"+UnameTb.Text+"' and SellerPass='"+PassTb.Text+"'",con);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        if(dt.Rows[0][0].ToString()=="1")
                        {
                            SellerName = UnameTb.Text;
                            SellerOptionListForm soptlist = new SellerOptionListForm();
                            soptlist.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Wrong User Name or Password");
                        }
                        con.Close();
                    }

                }
                else
                {
                    MessageBox.Show("Select a Role");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UnameTb.Text = "";
            PassTb.Text = "";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void RoleCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
