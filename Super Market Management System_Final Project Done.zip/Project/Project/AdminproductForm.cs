﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class AdminproductForm : Form
    {
        public AdminproductForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"data source=DESKTOP-1CECNH1\SQLEXPRESS;database = market;Integrated Security=True");
        private void button8_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            this.Hide();
            log.Show();
        }
        void fillcategory()
        {
            string query = "select* from CategoryTb";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("CatName", typeof(string));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                CatCombo.ValueMember = "CatName";
                CatCombo.DataSource = dt;
                SearchCombo.ValueMember = "CatName";
                SearchCombo.DataSource = dt;
                con.Close();
            }
            catch
            {

            }
        }
        void populate()
        {
            try
            {
                con.Open();
                string query = "select* from ProductTb";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                ProdDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        void filterbycategory()
        {
            try
            {
                con.Open();
                string query = "select* from ProductTb where ProdCat='" + SearchCombo.SelectedValue.ToString() + "'";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                ProdDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into ProductTb values('" + ProdIdTb.Text + "','" + ProdNameTb.Text + "','" + ProdQtyTb.Text + "','" + ProdPriceTb.Text + "','" + CatCombo.SelectedValue.ToString() + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Added Successfully");
                con.Close();
                populate();
            }
            catch
            {

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update ProductTb set ProdName='" + ProdNameTb.Text + "', ProdQty = '" + ProdQtyTb.Text + "', ProdPrice = '" + ProdPriceTb.Text + "',ProdCat='" + CatCombo.SelectedValue.ToString() + "'where ProdId = '" + ProdIdTb.Text + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Update Successfully");
                con.Close();
                populate();
            }
            catch
            {

            }
        }

        private void AdminproductForm_Load(object sender, EventArgs e)
        {
            populate();
            fillcategory();
            fillcategory();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (ProdIdTb.Text == "")
            {
                MessageBox.Show("Select The Product to Delete");
            }
            else
            {
                con.Open();
                string query = "delete from ProductTb where ProdId=" + ProdIdTb.Text + ";";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Deleted Successfully");
                con.Close();
                populate();
            }
        }

        private void ProdDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProdIdTb.Text = ProdDGV.SelectedRows[0].Cells[0].Value.ToString();
            ProdNameTb.Text = ProdDGV.SelectedRows[0].Cells[1].Value.ToString();
            ProdQtyTb.Text = ProdDGV.SelectedRows[0].Cells[2].Value.ToString();
            ProdPriceTb.Text = ProdDGV.SelectedRows[0].Cells[3].Value.ToString();
            CatCombo.SelectedValue = ProdDGV.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            filterbycategory();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OptionListForm opt = new OptionListForm();
            opt.Show();
            this.Hide();
        }
    }
}
