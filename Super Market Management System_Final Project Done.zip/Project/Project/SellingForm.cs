﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class SellingForm : Form
    {
        public SellingForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"data source=DESKTOP-1CECNH1\SQLEXPRESS;database = market;Integrated Security=True");
        void populate()
        {
            try
            {
                con.Open();
                string query = "select* from SellerTb1";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                SellerDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        void populateProducts()
        {
            try
            {
                con.Open();
                string query = "select* from ProductTb";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                ProdDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        void Categorypopulate()
        {
            con.Open();
            string query = "select* from CategoryTb";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CatDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            this.Hide();
            log.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void ProdDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void CatCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SellerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            AdminproductForm prod = new AdminproductForm();
            prod.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 login = new Form1();
            login.Show();
        }

        private void SellingForm_Load(object sender, EventArgs e)
        {
            populate();
            populateProducts();
            Categorypopulate();
            populateCustomer();
          
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click_1(object sender, EventArgs e)
        {
            category cat = new category();
            cat.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            sellerform seller = new sellerform();
            seller.Show();
        }

        private void CustomerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        void populateCustomer()
        {
            try
            {
                con.Open();
                string query = "select* from CustomerTb1";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                CustomerDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
          AdminCustomerForm2 cust = new AdminCustomerForm2();
            cust.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OptionListForm opt = new OptionListForm();
            opt.Show();
            this.Hide();
        }
    }
}
