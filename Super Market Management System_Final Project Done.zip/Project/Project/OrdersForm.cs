﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class OrdersForm : Form
    {
        public OrdersForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"data source=DESKTOP-1CECNH1\SQLEXPRESS;database = market;Integrated Security=True");
        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void CatDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            OrderIdTb.Text = OrderDgv.SelectedRows[0].Cells[0].Value.ToString();
            CustomerIdTb.Text = OrderDgv.SelectedRows[0].Cells[1].Value.ToString();
            SellerIdTb.Text = OrderDgv.SelectedRows[0].Cells[2].Value.ToString();
            productidtb.Text = OrderDgv.SelectedRows[0].Cells[3].Value.ToString();
            ProdPrice.Text = OrderDgv.SelectedRows[0].Cells[4].Value.ToString();
            PaymentCb.Text = OrderDgv.SelectedRows[0].Cells[5].Value.ToString();
            QtyTb.Text = OrderDgv.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            populate();
            populateseller();
            populateproduct();
            populateOrder();
            
        }
       
        void populateproduct()
        {
            try
            {
                con.Open();
                string query = "select* from ProductTb";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                ProdDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        void populateOrder()
        {
            try
            {
                con.Open();
                string query = "select* from OrderTb";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
               OrderDgv.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        void populate()
        {
            try
            {
                con.Open();
                string query = "select* from CustomerTb1";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                CustomerDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }
        void populateseller()
        {
            try
            {
                con.Open();
                string query = "select* from SellerTb1";
                SqlDataAdapter da = new SqlDataAdapter(query, con);

                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                SellerDGV.DataSource = ds.Tables[0];
                con.Close();

            }
            catch
            {

            }
        }

        private void CustomerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           CustomerIdTb.Text = CustomerDGV.SelectedRows[0].Cells[0].Value.ToString();
          // ProdPrice.Text = CustomerDGV.SelectedRows[0].Cells[1].Value.ToString();
           
           
        }

        private void CatCombo_SelectionChangeCommitted(object sender, EventArgs e)
        {
           
        }

        private void CatCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SellerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SellerIdTb.Text = SellerDGV.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
                
                
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into OrderTb values('" + OrderIdTb.Text + "','" + CustomerIdTb.Text + "','" + SellerIdTb.Text + "','" + productidtb.Text + "','" + ProdPrice.Text + "','" + PaymentCb.Text + "','" + QtyTb.Text + "')", con);
                
                
                cmd.ExecuteNonQuery();
                MessageBox.Show("Bill Added Successfuly");
                con.Close();
                populate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void PaymentTb_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            log.Show();
            this.Hide();
        }

        private void OrdersForm_Load(object sender, EventArgs e)
        {

        }
       

        private void ProdDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            productidtb.Text = ProdDGV.SelectedRows[0].Cells[0].Value.ToString();
            ProdPrice.Text = ProdDGV.SelectedRows[0].Cells[3].Value.ToString();
            
          
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SellerOptionListForm sopt = new SellerOptionListForm();
            sopt.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BillForm bill = new BillForm();
            bill.Show();
            this.Hide();
        }

        private void QtyTb_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void PaymentCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
